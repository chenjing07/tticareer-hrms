Ext.define('Admin.model.Base', {
    extend: 'Ext.data.Model',

    schema: {
        namespace: 'Admin.model'
    }
});
